- 👋 Hi, I’m @Bharadwaj-GLN
- 👀 I’m interested in Artificial Intelligence 🤖 👽, Data Science 📊 📈 and the concepts around it.
- 🌱 I’m currently learning Python 🐍, GitHub 💻, creating e-portfolios using GitHub 📚📜, and the concepts related to AI 👾🤖 and data science.
- 📫 How to reach me? - 📩 glnb1995@gmail.com - 📲 +918019761936 - 📸 @imbgln20

<!---
Bharadwaj-GLN/Bharadwaj-GLN is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
